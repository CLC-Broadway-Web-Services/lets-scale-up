
                    <div class="nk-footer nk-auth-footer-full">
                        <div class="container wide-lg">
                            <div class="row g-3">
                                <div class="col-lg-6 order-lg-last">
                                    <ul class="nav nav-sm justify-content-center justify-content-lg-end">
                                        <li class="nav-item">
                                            Developed by<a class="nav-link" href="https://www.clcbws.com" target="_blank">Broadway Web Services</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-6">
                                    <div class="nk-block-content text-center text-lg-left">
                                        <p class="text-soft">&copy; <?= date('Y') ?> Legalist. All Rights Reserved.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
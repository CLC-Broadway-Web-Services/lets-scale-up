
                        <div class="brand-logo pb-4 text-center">
                            <a href="/administrator" class="logo-link">
                                <img class="logo-light logo-img logo-img-lg" src="/public/dashboard/images/logo.png" srcset="/public/dashboard/images/logo2x.png 2x" alt="logo">
                                <img class="logo-dark logo-img logo-img-lg" src="/public/dashboard/images/logo-dark.png" srcset="/public/dashboard/images/logo-dark2x.png 2x" alt="logo-dark">
                            </a>
                        </div>
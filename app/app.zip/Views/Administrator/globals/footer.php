<!-- footer @s -->
<div class="nk-footer">
    <div class="container wide-xl">
        <div class="nk-footer-wrap g-2">
            <div class="nk-footer-copyright"> &copy; <?= date('Y') ?> DashLite. Template by <a href="#">Softnio</a>
            </div>
            <div class="nk-footer-links">
                <div class="nk-footer-copyright">
                    Developed by <a href="https://www.clcbws.com">Broadway Web Services</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- footer @e -->
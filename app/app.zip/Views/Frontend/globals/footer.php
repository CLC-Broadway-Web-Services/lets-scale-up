    <!-- START FOOTER -->
    <section class="py-5 bg-light">
        <div class="container">

            <div class="row">
                <div class="col-lg-4">
                    <div class="footer-info mt-4">
                        <img src="/public/assets/images/logo-dark.png" alt="" height="22">
                        <p class="text-muted mt-4 mb-2">Pretium viverra tinunt sagittis tempor.</p>
                        <img src="/public/assets/images/features/img-1.png" class="img-fluid" alt="">
                    </div>
                </div>
                <div class="col-lg-8 ">
                    <div class="row pl-0 pl-lg-3">
                        <div class="col-lg-3">
                            <div class="mt-4">
                                <h5 class="text-uppercase f-16">Product</h5>
                                <ul class="list-unstyled footer-link mt-3">
                                    <li><a href="">Services</a></li>
                                    <li><a href="">Features</a></li>
                                    <li><a href="">Credit</a></li>
                                    <li><a href="">Team</a></li>
                                    <li><a href="">Portfolio</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="mt-4">
                                <h5 class="text-uppercase f-16">Company</h5>
                                <ul class="list-unstyled footer-link mt-3">
                                    <li><a href="">Missions</a></li>
                                    <li><a href="">Carrers</a></li>
                                    <li><a href="">Investors</a></li>
                                    <li><a href="">Press</a></li>
                                    <li><a href="">Blog</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="mt-4">
                                <h5 class="text-uppercase f-16">More Info</h5>
                                <ul class="list-unstyled footer-link mt-3">
                                    <li><a href="">Pricing</a></li>
                                    <li><a href="">For Marketing</a></li>
                                    <li><a href="">For CEOs</a></li>
                                    <li><a href="">For Agencies</a></li>
                                    <li><a href="">Our Apps</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="mt-4">
                                <h5 class="text-uppercase f-16">Resources</h5>
                                <ul class="list-unstyled footer-link mt-3">
                                    <li><a href="">Form validation</a></li>
                                    <li><a href="">Visibility</a></li>
                                    <li><a href="">Accessibility</a></li>
                                    <li><a href="">Design Defined</a></li>
                                    <li><a href="">Marketplace</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <hr class="my-5">

            <div class="row">
                <div class="col-12">
                    <div class="text-center">
                        <p class="text-muted mb-0"><?=date('Y')?> &copy; <a href="<?= APP_URL ?>"><?= APP_NAME ?></a>. Developed & Design by <a href="https://www.clcbws.com" target="_blank" title="Broadway Web Services">BWS</a></p>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- END FOOTER -->
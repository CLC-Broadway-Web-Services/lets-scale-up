<?php

namespace App\Controllers\Frontend;

use CodeIgniter\Controller;

class Home2 extends Controller
{
	public function index()
	{
		// $servicesDB = new FrontservicesModel();
		// $services = $servicesDB->getAllHomepageServices();
		// // return print_r($services);
		// $data['services'] = $services;

		$data['pageCSS'] = '<link rel="stylesheet" href="/public/libraries/splide/dist/css/splide.min.css">';

		$data['pageJSbefore'] = '
		<script src="/public/libraries/splide/dist/js/splide.min.js"></script>';

		$data['pageJS'] = '<script src="/public/assets/js/counter.init.js"></script>
		<script src="/public/custom/assets/js/homepage2.js"></script>';

		return view('Frontend/pages2/homepage', $data);
	}

	//--------------------------------------------------------------------

}

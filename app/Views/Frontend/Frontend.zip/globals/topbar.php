<div class="topbar">
    <div class="container">
        <div class="float-left">
            <div class="phone-topbar">
                <ul class="list-inline topbar-link mb-0">
                    <li class="list-inline-item mr-4 pr-2"><a href="mailto:lsuexperts@gmail.com"><i class="mdi mdi-email mr-2 f-16"></i>lsuexperts@gmail.com</a></li>
                </ul>
            </div>
        </div>
        <div class="float-right">
            <ul class="list-inline topbar-social pb-0 pt-2 mt-1 mb-0">
                <li class="list-inline-item pl-2"><a href="<?= LINKEDIN; ?>" class=""><i class="mdi mdi-linkedin"></i></a></li>
                <li class="list-inline-item pl-2"><a href="<?= INSTAGRAM; ?>" class=""><i class="mdi mdi-instagram"></i></a></li>
                <li class="list-inline-item pl-2"><a href="<?= TWITTER; ?>" class=""><i class="mdi mdi-twitter"></i></a></li>
                <li class="list-inline-item pl-2"><a href="<?= YOUTUBE; ?>" class=""><i class="mdi mdi-youtube"></i></a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
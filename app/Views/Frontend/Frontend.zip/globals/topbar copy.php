    <!-- TAGLINE HEADER START-->
    <div class="topbar">
        <div class="container">
            <div class="float-left">
                <div class="phone-topbar">
                    <ul class="list-inline topbar-link mb-0">

                        <li class="list-inline-item mr-4 pr-2">
                            <img src="/public/assets/images/logo-light.png" alt="" height="22">
                        </li>
                        <li class="list-inline-item mr-4 pr-2">
                            <a href="">
                                <i class="mdi mdi-email mr-2 f-16"></i>Support@example.com
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href=""><i class="mdi mdi-phone mr-2 f-16"></i>
                                1800 000 0000 / 23235 23235
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="float-right">
                <div class="phone-topbar">
                    <ul class="list-inline topbar-link mb-0">
                        <li class="list-inline-item mr-4 pr-2">
                            <a href="">
                                <i class="mdi mdi-login mr-2 f-16"></i>Login
                            </a>
                        </li>
                        <li class="list-inline-item mr-4 pr-2">
                            <a href="">
                                <i class="mdi mdi-login mr-2 f-16"></i>Signup
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- <div class="float-right"> -->
            <!-- <ul class="list-inline pb-0 pt-2 mt-1 mb-0"> -->
            <!-- <li class="list-inline-item pl-2"><a href="#" class=""><i class="mdi mdi-facebook"></i></a></li>
                    <li class="list-inline-item pl-2"><a href="#" class=""><i class="mdi mdi-twitter"></i></a>
                    </li>
                    <li class="list-inline-item pl-2"><a href="#" class=""><i class="mdi mdi-instagram"></i></a></li>
                    <li class="list-inline-item pl-2"><a href="#" class=""><i class="mdi mdi-google-plus"></i></a></li> -->
            <!-- <li class="list-inline-item mr-4 pr-2"><a href=""><i class="mdi mdi-email mr-2 f-16"></i>example</a></li> -->
            <!-- <li class="list-inline-item mr-4 pr-2"><a href=""><i class="mdi mdi-email mr-2 f-16"></i>Support</a></li> -->
            <!-- <li class="list-inline-item">
                        <a href="" class="btn btn-sm btn-primary btn-round">Log In</a>
                    </li> -->
            <!-- <div class="navbar-button d-none d-lg-inline-block">
                        <a href="" class="btn btn-sm btn-primary btn-round">Sign Up</a>
                    </div> -->
            <!-- </ul> -->
            <!-- </div> -->
            <div class="clearfix"></div>
        </div>
    </div>
    <!-- Static navbar -->